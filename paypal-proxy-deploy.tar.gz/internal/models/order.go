package models

import (
	"time"
)

// WooCommerce Order structure
type Order struct {
	ID                int                `json:"id"`
	Number            string             `json:"number"`
	Status            string             `json:"status"`
	Currency          string             `json:"currency"`
	Total             string             `json:"total"`
	PaymentMethod     string             `json:"payment_method"`
	PaymentMethodTitle string            `json:"payment_method_title"`
	TransactionID     string             `json:"transaction_id"`
	DateCreated       time.Time          `json:"date_created"`
	DatePaid          *time.Time         `json:"date_paid"`
	OrderKey          string             `json:"order_key"`
	CustomerNote      string             `json:"customer_note"`
	Billing           BillingAddress     `json:"billing"`
	Shipping          ShippingAddress    `json:"shipping"`
	LineItems         []LineItem         `json:"line_items"`
	ShippingLines     []ShippingLine     `json:"shipping_lines"`
	FeeLines          []FeeLine          `json:"fee_lines"`
	TaxLines          []TaxLine          `json:"tax_lines"`
	CouponLines       []CouponLine       `json:"coupon_lines"`
	MetaData          []MetaData         `json:"meta_data"`
}

type BillingAddress struct {
	FirstName string `json:"first_name"`
	LastName  string `json:"last_name"`
	Company   string `json:"company"`
	Address1  string `json:"address_1"`
	Address2  string `json:"address_2"`
	City      string `json:"city"`
	State     string `json:"state"`
	Postcode  string `json:"postcode"`
	Country   string `json:"country"`
	Email     string `json:"email"`
	Phone     string `json:"phone"`
}

type ShippingAddress struct {
	FirstName string `json:"first_name"`
	LastName  string `json:"last_name"`
	Company   string `json:"company"`
	Address1  string `json:"address_1"`
	Address2  string `json:"address_2"`
	City      string `json:"city"`
	State     string `json:"state"`
	Postcode  string `json:"postcode"`
	Country   string `json:"country"`
}

type LineItem struct {
	ID          int        `json:"id"`
	Name        string     `json:"name"`
	ProductID   int        `json:"product_id"`
	VariationID int        `json:"variation_id"`
	Quantity    int        `json:"quantity"`
	SKU         string     `json:"sku"`
	Price       float64    `json:"price"`
	Subtotal    string     `json:"subtotal"`
	Total       string     `json:"total"`
	MetaData    []MetaData `json:"meta_data"`
}

type ShippingLine struct {
	ID          int        `json:"id"`
	MethodID    string     `json:"method_id"`
	MethodTitle string     `json:"method_title"`
	Total       string     `json:"total"`
	MetaData    []MetaData `json:"meta_data"`
}

type FeeLine struct {
	ID       int        `json:"id"`
	Name     string     `json:"name"`
	Total    string     `json:"total"`
	MetaData []MetaData `json:"meta_data"`
}

type TaxLine struct {
	ID               int        `json:"id"`
	RateCode         string     `json:"rate_code"`
	RateID           int        `json:"rate_id"`
	Label            string     `json:"label"`
	Compound         bool       `json:"compound"`
	TaxTotal         string     `json:"tax_total"`
	ShippingTaxTotal string     `json:"shipping_tax_total"`
	MetaData         []MetaData `json:"meta_data"`
}

type CouponLine struct {
	ID          int        `json:"id"`
	Code        string     `json:"code"`
	Discount    string     `json:"discount"`
	DiscountTax string     `json:"discount_tax"`
	MetaData    []MetaData `json:"meta_data"`
}

type MetaData struct {
	ID    int         `json:"id"`
	Key   string      `json:"key"`
	Value interface{} `json:"value"`
}

// Proxy Order for creating anonymized orders on OITAM
type ProxyOrderRequest struct {
	Number            string             `json:"number"`
	PaymentMethod     string             `json:"payment_method"`
	PaymentMethodTitle string            `json:"payment_method_title"`
	SetPaid           bool               `json:"set_paid"`
	Status            string             `json:"status"`
	Billing           BillingAddress     `json:"billing"`
	Shipping          ShippingAddress    `json:"shipping"`
	CustomerID        int                `json:"customer_id"`
	Currency          string             `json:"currency"`
	LineItems         []ProxyLineItem    `json:"line_items"`
	ShippingLines     []ShippingLine     `json:"shipping_lines"`
	FeeLines          []FeeLine          `json:"fee_lines"`
	CouponLines       []CouponLine       `json:"coupon_lines"`
	TaxLines          []TaxLine          `json:"tax_lines"`
	Total             string             `json:"total"`
	CustomerNote      string             `json:"customer_note"`
	MetaData          []MetaData         `json:"meta_data"`
}

type ProxyLineItem struct {
	Name        string  `json:"name"`
	ProductID   int     `json:"product_id"`
	VariationID int     `json:"variation_id"`
	Quantity    int     `json:"quantity"`
	SKU         string  `json:"sku"`
	Price       float64 `json:"price"`
	Subtotal    string  `json:"subtotal"`
	Total       string  `json:"total"`
	MetaData    []MetaData `json:"meta_data"`
}

// Payment redirect response
type PaymentRedirectResponse struct {
	RedirectURL string `json:"redirect_url"`
	OrderID     string `json:"order_id"`
	ProxyOrderID int   `json:"proxy_order_id"`
	Status      string `json:"status"`
}

// Error response
type ErrorResponse struct {
	Error   string `json:"error"`
	Message string `json:"message"`
	Code    int    `json:"code"`
}

// Health check response
type HealthResponse struct {
	Status    string    `json:"status"`
	Timestamp time.Time `json:"timestamp"`
	Version   string    `json:"version"`
	Uptime    string    `json:"uptime"`
}