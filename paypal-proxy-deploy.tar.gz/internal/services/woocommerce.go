package services

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"time"

	"paypal-proxy/internal/config"
	"paypal-proxy/internal/models"

	"github.com/sirupsen/logrus"
)

type WooCommerceService struct {
	config     *config.Config
	httpClient *http.Client
	logger     *logrus.Logger
}

func NewWooCommerceService(cfg *config.Config) *WooCommerceService {
	return &WooCommerceService{
		config: cfg,
		httpClient: &http.Client{
			Timeout: time.Duration(cfg.APITimeout) * time.Second,
		},
		logger: logrus.New(),
	}
}

// Get order from MagicSpore
func (w *WooCommerceService) GetMagicOrder(ctx context.Context, orderID string) (*models.Order, error) {
	url := fmt.Sprintf("%s/%s", w.config.MagicSpore.APIURL, orderID)
	
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	// Add basic auth
	auth := base64.StdEncoding.EncodeToString([]byte(
		fmt.Sprintf("%s:%s", w.config.MagicSpore.ConsumerKey, w.config.MagicSpore.ConsumerSecret),
	))
	req.Header.Set("Authorization", "Basic "+auth)
	req.Header.Set("Content-Type", "application/json")

	resp, err := w.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to execute request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		w.logger.Errorf("Failed to get MagicSpore order %s: %s", orderID, string(body))
		return nil, fmt.Errorf("API returned status %d: %s", resp.StatusCode, string(body))
	}

	var order models.Order
	if err := json.NewDecoder(resp.Body).Decode(&order); err != nil {
		return nil, fmt.Errorf("failed to decode response: %w", err)
	}

	w.logger.Infof("Successfully retrieved MagicSpore order %s", orderID)
	return &order, nil
}

// Create proxy order on OITAM
func (w *WooCommerceService) CreateOITAMOrder(ctx context.Context, magicOrder *models.Order) (*models.Order, error) {
	// Create anonymized proxy order
	proxyOrder := w.createProxyOrder(magicOrder)
	
	jsonData, err := json.Marshal(proxyOrder)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal proxy order: %w", err)
	}

	req, err := http.NewRequestWithContext(ctx, "POST", w.config.OITAM.APIURL, bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	// Add basic auth
	auth := base64.StdEncoding.EncodeToString([]byte(
		fmt.Sprintf("%s:%s", w.config.OITAM.ConsumerKey, w.config.OITAM.ConsumerSecret),
	))
	req.Header.Set("Authorization", "Basic "+auth)
	req.Header.Set("Content-Type", "application/json")

	resp, err := w.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to execute request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusCreated {
		body, _ := io.ReadAll(resp.Body)
		w.logger.Errorf("Failed to create OITAM order: %s", string(body))
		return nil, fmt.Errorf("API returned status %d: %s", resp.StatusCode, string(body))
	}

	var oitamOrder models.Order
	if err := json.NewDecoder(resp.Body).Decode(&oitamOrder); err != nil {
		return nil, fmt.Errorf("failed to decode response: %w", err)
	}

	w.logger.Infof("Successfully created OITAM proxy order %d for MagicSpore order %s", oitamOrder.ID, magicOrder.Number)
	return &oitamOrder, nil
}

// Update MagicSpore order status
func (w *WooCommerceService) UpdateMagicOrder(ctx context.Context, orderID string, status string, additionalData map[string]interface{}) error {
	url := fmt.Sprintf("%s/%s", w.config.MagicSpore.APIURL, orderID)
	
	updateData := map[string]interface{}{
		"status": status,
	}
	
	// Merge additional data
	for key, value := range additionalData {
		updateData[key] = value
	}

	jsonData, err := json.Marshal(updateData)
	if err != nil {
		return fmt.Errorf("failed to marshal update data: %w", err)
	}

	req, err := http.NewRequestWithContext(ctx, "PUT", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return fmt.Errorf("failed to create request: %w", err)
	}

	// Add basic auth
	auth := base64.StdEncoding.EncodeToString([]byte(
		fmt.Sprintf("%s:%s", w.config.MagicSpore.ConsumerKey, w.config.MagicSpore.ConsumerSecret),
	))
	req.Header.Set("Authorization", "Basic "+auth)
	req.Header.Set("Content-Type", "application/json")

	resp, err := w.httpClient.Do(req)
	if err != nil {
		return fmt.Errorf("failed to execute request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		w.logger.Errorf("Failed to update MagicSpore order %s: %s", orderID, string(body))
		return fmt.Errorf("API returned status %d: %s", resp.StatusCode, string(body))
	}

	w.logger.Infof("Successfully updated MagicSpore order %s to status %s", orderID, status)
	return nil
}

// Get OITAM order status
func (w *WooCommerceService) GetOITAMOrder(ctx context.Context, orderID string) (*models.Order, error) {
	url := fmt.Sprintf("%s/%s", w.config.OITAM.APIURL, orderID)
	
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	// Add basic auth
	auth := base64.StdEncoding.EncodeToString([]byte(
		fmt.Sprintf("%s:%s", w.config.OITAM.ConsumerKey, w.config.OITAM.ConsumerSecret),
	))
	req.Header.Set("Authorization", "Basic "+auth)
	req.Header.Set("Content-Type", "application/json")

	resp, err := w.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to execute request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("API returned status %d: %s", resp.StatusCode, string(body))
	}

	var order models.Order
	if err := json.NewDecoder(resp.Body).Decode(&order); err != nil {
		return nil, fmt.Errorf("failed to decode response: %w", err)
	}

	return &order, nil
}

// Create anonymized proxy order
func (w *WooCommerceService) createProxyOrder(magicOrder *models.Order) *models.ProxyOrderRequest {
	// Create anonymized line items
	var proxyLineItems []models.ProxyLineItem
	for i, item := range magicOrder.LineItems {
		proxyItem := models.ProxyLineItem{
			Name:        fmt.Sprintf("Item %d", i+1), // Generic name
			ProductID:   0,                           // No product reference
			VariationID: 0,
			Quantity:    item.Quantity,
			SKU:         item.SKU, // Keep original SKU if exists
			Price:       item.Price,
			Subtotal:    item.Subtotal,
			Total:       item.Total,
			MetaData:    []models.MetaData{}, // No product metadata
		}
		proxyLineItems = append(proxyLineItems, proxyItem)
	}

	// Get billing country (required for PayPal)
	billingCountry := "US"
	if magicOrder.Billing.Country != "" {
		billingCountry = magicOrder.Billing.Country
	}

	shippingCountry := billingCountry
	if magicOrder.Shipping.Country != "" {
		shippingCountry = magicOrder.Shipping.Country
	}

	return &models.ProxyOrderRequest{
		Number:            magicOrder.Number, // Keep same order number
		PaymentMethod:     "paypal",
		PaymentMethodTitle: "PayPal",
		SetPaid:           false,
		Status:            "pending",
		Billing: models.BillingAddress{
			FirstName: "Customer",
			LastName:  "Order",
			Company:   "",
			Address1:  "Private",
			Address2:  "",
			City:      "Private",
			State:     "",
			Postcode:  "00000",
			Country:   billingCountry,
			Email:     "noreply@oitam.com",
			Phone:     "",
		},
		Shipping: models.ShippingAddress{
			FirstName: "Customer",
			LastName:  "Order",
			Company:   "",
			Address1:  "Private",
			Address2:  "",
			City:      "Private",
			State:     "",
			Postcode:  "00000",
			Country:   shippingCountry,
		},
		CustomerID:    0, // Guest checkout
		Currency:      magicOrder.Currency,
		LineItems:     proxyLineItems,
		ShippingLines: magicOrder.ShippingLines,
		FeeLines:      magicOrder.FeeLines,
		CouponLines:   []models.CouponLine{}, // Remove coupon info
		TaxLines:      magicOrder.TaxLines,
		Total:         magicOrder.Total,
		CustomerNote:  "", // No notes
		MetaData: []models.MetaData{
			{
				Key:   "_original_order_id",
				Value: strconv.Itoa(magicOrder.ID),
			},
			{
				Key:   "_proxy_order",
				Value: "true",
			},
		},
	}
}

// Check if order is already paid
func (w *WooCommerceService) IsOrderPaid(order *models.Order) bool {
	paidStatuses := []string{"completed", "processing", "on-hold"}
	for _, status := range paidStatuses {
		if order.Status == status {
			return true
		}
	}
	return false
}