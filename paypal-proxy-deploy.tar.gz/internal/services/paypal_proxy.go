package services

import (
	"context"
	"fmt"
	"net/url"
	"paypal-proxy/internal/config"
	"paypal-proxy/internal/models"
	"strconv"
	"time"

	"github.com/sirupsen/logrus"
)

type PayPalProxyService struct {
	config     *config.Config
	wooService *WooCommerceService
	logger     *logrus.Logger
}

func NewPayPalProxyService(cfg *config.Config, wooService *WooCommerceService) *PayPalProxyService {
	return &PayPalProxyService{
		config:     cfg,
		wooService: wooService,
		logger:     logrus.New(),
	}
}

// Handle payment redirect - main proxy logic
func (p *PayPalProxyService) HandlePaymentRedirect(ctx context.Context, orderID string, domain string) (*models.PaymentRedirectResponse, error) {
	p.logger.Infof("Processing payment redirect for order %s", orderID)

	// 1. Fetch original order from MagicSpore
	magicOrder, err := p.wooService.GetMagicOrder(ctx, orderID)
	if err != nil {
		p.logger.Errorf("Failed to fetch MagicSpore order %s: %v", orderID, err)
		return nil, fmt.Errorf("failed to fetch original order: %w", err)
	}

	// 2. Check if order is already paid
	if p.wooService.IsOrderPaid(magicOrder) {
		p.logger.Infof("Order %s is already paid, redirecting to success", orderID)
		successURL := fmt.Sprintf("%s?order=%s&already_paid=1", p.config.ReturnURLs.Success, orderID)
		return &models.PaymentRedirectResponse{
			RedirectURL:  successURL,
			OrderID:      orderID,
			ProxyOrderID: 0,
			Status:       "already_paid",
		}, nil
	}

	// 3. Create proxy order on OITAM
	oitamOrder, err := p.wooService.CreateOITAMOrder(ctx, magicOrder)
	if err != nil {
		p.logger.Errorf("Failed to create OITAM order for %s: %v", orderID, err)
		return nil, fmt.Errorf("failed to create payment order: %w", err)
	}

	// 4. Build return and cancel URLs
	returnURL := fmt.Sprintf("https://%s/paypal-return?order_id=%s&oitam_order_id=%d&status=success", 
		domain, orderID, oitamOrder.ID)
	cancelURL := fmt.Sprintf("https://%s/paypal-cancel?order_id=%s&oitam_order_id=%d", 
		domain, orderID, oitamOrder.ID)

	// 5. Build checkout URL
	checkoutURL := p.buildCheckoutURL(oitamOrder, returnURL, cancelURL)

	p.logger.Infof("Successfully created proxy order %d for MagicSpore order %s", oitamOrder.ID, orderID)

	return &models.PaymentRedirectResponse{
		RedirectURL:  checkoutURL,
		OrderID:      orderID,
		ProxyOrderID: oitamOrder.ID,
		Status:       "redirect_created",
	}, nil
}

// Handle PayPal return (success)
func (p *PayPalProxyService) HandlePayPalReturn(ctx context.Context, params map[string]string) (string, error) {
	orderID := params["order_id"]
	oitamOrderID := params["oitam_order_id"]
	paymentID := params["paymentId"]
	payerID := params["PayerID"]

	if orderID == "" {
		return p.config.ReturnURLs.Error + "?error=missing_order_id", nil
	}

	p.logger.Infof("Processing PayPal return for order %s, OITAM order %s", orderID, oitamOrderID)

	// Verify payment status from OITAM order
	if oitamOrderID != "" {
		oitamOrder, err := p.wooService.GetOITAMOrder(ctx, oitamOrderID)
		if err == nil && p.wooService.IsOrderPaid(oitamOrder) {
			// Payment confirmed, update original order
			err = p.updateOriginalOrderWithPayment(ctx, orderID, paymentID, payerID, oitamOrderID, oitamOrder.TransactionID)
			if err != nil {
				p.logger.Errorf("Failed to update original order %s: %v", orderID, err)
			}

			return fmt.Sprintf("%s?order=%s&payment=confirmed", p.config.ReturnURLs.Success, orderID), nil
		}
	}

	// Fallback: update order status based on URL parameters
	if paymentID != "" || payerID != "" {
		err := p.updateOriginalOrderWithPayment(ctx, orderID, paymentID, payerID, oitamOrderID, "")
		if err != nil {
			p.logger.Errorf("Failed to update original order %s: %v", orderID, err)
		}
		
		return fmt.Sprintf("%s?order=%s&payment=success", p.config.ReturnURLs.Success, orderID), nil
	}

	// If we can't confirm payment, redirect to error page
	p.logger.Warnf("Could not verify payment for order %s", orderID)
	return fmt.Sprintf("%s?order=%s&error=payment_verification_failed", p.config.ReturnURLs.Error, orderID), nil
}

// Handle PayPal cancel
func (p *PayPalProxyService) HandlePayPalCancel(ctx context.Context, orderID, oitamOrderID string) (string, error) {
	p.logger.Infof("Processing PayPal cancellation for order %s", orderID)

	if orderID != "" {
		// Update order with cancelled status
		additionalData := map[string]interface{}{
			"customer_note": "Payment cancelled by customer",
		}
		
		err := p.wooService.UpdateMagicOrder(ctx, orderID, "cancelled", additionalData)
		if err != nil {
			p.logger.Errorf("Failed to update cancelled order %s: %v", orderID, err)
		}
	}

	return fmt.Sprintf("%s?order=%s&payment=cancelled", p.config.ReturnURLs.Cancel, orderID), nil
}

// Handle webhook (PayPal IPN or WooCommerce webhooks)
func (p *PayPalProxyService) HandleWebhook(ctx context.Context, webhookData map[string]interface{}) error {
	p.logger.Infof("Processing webhook: %+v", webhookData)

	eventType, exists := webhookData["event_type"].(string)
	if !exists {
		return fmt.Errorf("webhook event_type not found")
	}

	switch eventType {
	case "PAYMENT.CAPTURE.COMPLETED":
		return p.handlePaymentCaptureCompleted(ctx, webhookData)
	default:
		p.logger.Infof("Unhandled webhook event type: %s", eventType)
	}

	return nil
}

// Build OITAM checkout URL
func (p *PayPalProxyService) buildCheckoutURL(order *models.Order, returnURL, cancelURL string) string {
	checkoutURL, _ := url.Parse(fmt.Sprintf("%s/%d/", p.config.OITAM.CheckoutURL, order.ID))
	
	params := url.Values{}
	params.Set("pay_for_order", "true")
	params.Set("key", order.OrderKey)
	params.Set("return_url", returnURL)
	params.Set("cancel_return", cancelURL)
	
	checkoutURL.RawQuery = params.Encode()
	return checkoutURL.String()
}

// Update original order with payment information
func (p *PayPalProxyService) updateOriginalOrderWithPayment(ctx context.Context, orderID, paymentID, payerID, oitamOrderID, transactionID string) error {
	now := time.Now()
	
	additionalData := map[string]interface{}{
		"payment_method":       "paypal",
		"payment_method_title": "PayPal",
		"date_paid":           now.Format(time.RFC3339),
		"meta_data": []models.MetaData{
			{
				Key:   "_paypal_payment_id",
				Value: paymentID,
			},
			{
				Key:   "_paypal_payer_id", 
				Value: payerID,
			},
			{
				Key:   "_oitam_order_id",
				Value: oitamOrderID,
			},
		},
	}

	// Use transaction ID from OITAM if available
	if transactionID != "" {
		additionalData["transaction_id"] = transactionID
	} else if paymentID != "" {
		additionalData["transaction_id"] = paymentID
	}

	return p.wooService.UpdateMagicOrder(ctx, orderID, "processing", additionalData)
}

// Handle PayPal payment capture completed webhook
func (p *PayPalProxyService) handlePaymentCaptureCompleted(ctx context.Context, webhookData map[string]interface{}) error {
	resource, exists := webhookData["resource"].(map[string]interface{})
	if !exists {
		return fmt.Errorf("webhook resource not found")
	}

	// Try to get order ID from custom_id or invoice_id
	var orderID string
	if customID, exists := resource["custom_id"].(string); exists {
		orderID = customID
	} else if invoiceID, exists := resource["invoice_id"].(string); exists {
		orderID = invoiceID
	}

	if orderID == "" {
		return fmt.Errorf("order ID not found in webhook")
	}

	// Get payment ID
	paymentID := ""
	if id, exists := resource["id"].(string); exists {
		paymentID = id
	}

	// Update order to completed status
	additionalData := map[string]interface{}{
		"transaction_id":   paymentID,
		"payment_method":   "paypal",
		"date_paid":       time.Now().Format(time.RFC3339),
	}

	return p.wooService.UpdateMagicOrder(ctx, orderID, "completed", additionalData)
}

// Get order status
func (p *PayPalProxyService) GetOrderStatus(ctx context.Context, orderID string) (*models.Order, error) {
	return p.wooService.GetMagicOrder(ctx, orderID)
}