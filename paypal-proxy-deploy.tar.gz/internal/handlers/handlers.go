package handlers

import (
	"net/http"
	"paypal-proxy/internal/models"
	"paypal-proxy/internal/services"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/sirupsen/logrus"
)

type Handler struct {
	paypalService *services.PayPalProxyService
	wooService    *services.WooCommerceService
	logger        *logrus.Logger
	startTime     time.Time
}

func New(paypalService *services.PayPalProxyService, wooService *services.WooCommerceService) *Handler {
	return &Handler{
		paypalService: paypalService,
		wooService:    wooService,
		logger:        logrus.New(),
		startTime:     time.Now(),
	}
}

// Health check endpoint
func (h *Handler) HealthCheck(c *gin.Context) {
	uptime := time.Since(h.startTime)
	
	response := models.HealthResponse{
		Status:    "OK",
		Timestamp: time.Now(),
		Version:   "1.0.0",
		Uptime:    uptime.String(),
	}
	
	c.JSON(http.StatusOK, response)
}

// Payment redirect endpoint - main proxy entry point
func (h *Handler) PaymentRedirect(c *gin.Context) {
	orderID := c.Query("orderId")
	if orderID == "" {
		h.respondWithError(c, http.StatusBadRequest, "Missing orderId parameter", nil)
		return
	}

	h.logger.Infof("Payment redirect request for order %s", orderID)

	// Get domain for return URLs
	domain := c.Request.Host

	// Process payment redirect
	result, err := h.paypalService.HandlePaymentRedirect(c.Request.Context(), orderID, domain)
	if err != nil {
		h.logger.Errorf("Payment redirect failed for order %s: %v", orderID, err)
		h.respondWithError(c, http.StatusInternalServerError, "Failed to process payment redirect", err)
		return
	}

	// Redirect to PayPal checkout
	c.Redirect(http.StatusFound, result.RedirectURL)
}

// PayPal return handler (success)
func (h *Handler) PayPalReturn(c *gin.Context) {
	params := map[string]string{
		"order_id":       c.Query("order_id"),
		"oitam_order_id": c.Query("oitam_order_id"),
		"status":         c.Query("status"),
		"paymentId":      c.Query("paymentId"),
		"PayerID":        c.Query("PayerID"),
	}

	h.logger.Infof("PayPal return for order %s", params["order_id"])

	redirectURL, err := h.paypalService.HandlePayPalReturn(c.Request.Context(), params)
	if err != nil {
		h.logger.Errorf("PayPal return handling failed: %v", err)
		redirectURL = "/blad-platnosci?error=return_handler_failed"
	}

	c.Redirect(http.StatusFound, redirectURL)
}

// PayPal cancel handler
func (h *Handler) PayPalCancel(c *gin.Context) {
	orderID := c.Query("order_id")
	oitamOrderID := c.Query("oitam_order_id")

	h.logger.Infof("PayPal cancellation for order %s", orderID)

	redirectURL, err := h.paypalService.HandlePayPalCancel(c.Request.Context(), orderID, oitamOrderID)
	if err != nil {
		h.logger.Errorf("PayPal cancel handling failed: %v", err)
		redirectURL = "/blad-platnosci?error=cancel_handler_failed"
	}

	c.Redirect(http.StatusFound, redirectURL)
}

// Webhook handler (PayPal IPN or WooCommerce webhooks)
func (h *Handler) WebhookHandler(c *gin.Context) {
	var webhookData map[string]interface{}
	if err := c.ShouldBindJSON(&webhookData); err != nil {
		h.logger.Errorf("Failed to parse webhook data: %v", err)
		h.respondWithError(c, http.StatusBadRequest, "Invalid webhook data", err)
		return
	}

	h.logger.Infof("Webhook received: %+v", webhookData)

	err := h.paypalService.HandleWebhook(c.Request.Context(), webhookData)
	if err != nil {
		h.logger.Errorf("Webhook processing failed: %v", err)
		h.respondWithError(c, http.StatusInternalServerError, "Webhook processing failed", err)
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Webhook processed successfully"})
}

// Get order information
func (h *Handler) GetOrder(c *gin.Context) {
	orderID := c.Param("id")
	
	order, err := h.paypalService.GetOrderStatus(c.Request.Context(), orderID)
	if err != nil {
		h.logger.Errorf("Failed to get order %s: %v", orderID, err)
		h.respondWithError(c, http.StatusNotFound, "Order not found", err)
		return
	}

	c.JSON(http.StatusOK, order)
}

// Create order (for testing)
func (h *Handler) CreateOrder(c *gin.Context) {
	var order models.Order
	if err := c.ShouldBindJSON(&order); err != nil {
		h.respondWithError(c, http.StatusBadRequest, "Invalid order data", err)
		return
	}

	// This would be implemented if needed for testing
	c.JSON(http.StatusCreated, gin.H{"message": "Order creation not implemented"})
}

// Update order (for testing)
func (h *Handler) UpdateOrder(c *gin.Context) {
	orderID := c.Param("id")
	
	var updateData map[string]interface{}
	if err := c.ShouldBindJSON(&updateData); err != nil {
		h.respondWithError(c, http.StatusBadRequest, "Invalid update data", err)
		return
	}

	// This would be implemented if needed for testing
	c.JSON(http.StatusOK, gin.H{
		"message": "Order update not implemented", 
		"order_id": orderID,
	})
}

// Get order status
func (h *Handler) GetOrderStatus(c *gin.Context) {
	orderID := c.Param("id")
	
	order, err := h.paypalService.GetOrderStatus(c.Request.Context(), orderID)
	if err != nil {
		h.logger.Errorf("Failed to get order status %s: %v", orderID, err)
		h.respondWithError(c, http.StatusNotFound, "Order not found", err)
		return
	}

	statusResponse := map[string]interface{}{
		"order_id": orderID,
		"status":   order.Status,
		"total":    order.Total,
		"currency": order.Currency,
		"payment_method": order.PaymentMethod,
		"date_created": order.DateCreated,
		"date_paid": order.DatePaid,
	}

	c.JSON(http.StatusOK, statusResponse)
}

// Helper function to respond with error
func (h *Handler) respondWithError(c *gin.Context, statusCode int, message string, err error) {
	errorResponse := models.ErrorResponse{
		Error:   message,
		Code:    statusCode,
		Message: message,
	}
	
	if err != nil {
		errorResponse.Message = err.Error()
	}
	
	c.JSON(statusCode, errorResponse)
}