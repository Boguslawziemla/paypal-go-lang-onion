package config

import (
	"os"
	"strconv"
)

type Config struct {
	Environment   string
	Port          string
	LogLevel      string
	
	// MagicSpore (source) configuration
	MagicSpore MagicSporeConfig
	
	// OITAM (payment processor) configuration
	OITAM OITAMConfig
	
	// Return URLs
	ReturnURLs ReturnURLsConfig
	
	// Security
	APITimeout int
	RateLimit  int
}

type MagicSporeConfig struct {
	APIURL        string
	ConsumerKey   string
	ConsumerSecret string
}

type OITAMConfig struct {
	APIURL        string
	ConsumerKey   string
	ConsumerSecret string
	CheckoutURL   string
}

type ReturnURLsConfig struct {
	Success string
	Cancel  string
	Error   string
}

func New() *Config {
	return &Config{
		Environment: getEnv("ENVIRONMENT", "development"),
		Port:        getEnv("PORT", "8080"),
		LogLevel:    getEnv("LOG_LEVEL", "info"),
		
		MagicSpore: MagicSporeConfig{
			APIURL:        getEnv("MAGIC_API_URL", "https://magicspore.com/wp-json/wc/v3/orders"),
			ConsumerKey:   getEnv("MAGIC_CONSUMER_KEY", ""),
			ConsumerSecret: getEnv("MAGIC_CONSUMER_SECRET", ""),
		},
		
		OITAM: OITAMConfig{
			APIURL:        getEnv("OITAM_API_URL", "https://oitam.com/wp-json/wc/v3/orders"),
			ConsumerKey:   getEnv("OITAM_CONSUMER_KEY", ""),
			ConsumerSecret: getEnv("OITAM_CONSUMER_SECRET", ""),
			CheckoutURL:   getEnv("OITAM_CHECKOUT_URL", "https://oitam.com/checkout/order-pay"),
		},
		
		ReturnURLs: ReturnURLsConfig{
			Success: getEnv("RETURN_URL_SUCCESS", "https://magicspore.com/dziekujemy"),
			Cancel:  getEnv("RETURN_URL_CANCEL", "https://magicspore.com/koszyk"),
			Error:   getEnv("RETURN_URL_ERROR", "https://magicspore.com/blad-platnosci"),
		},
		
		APITimeout: getEnvInt("API_TIMEOUT", 30),
		RateLimit:  getEnvInt("RATE_LIMIT", 100),
	}
}

func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}

func getEnvInt(key string, defaultValue int) int {
	if value := os.Getenv(key); value != "" {
		if intValue, err := strconv.Atoi(value); err == nil {
			return intValue
		}
	}
	return defaultValue
}

func (c *Config) Validate() error {
	if c.MagicSpore.ConsumerKey == "" {
		return NewValidationError("MAGIC_CONSUMER_KEY is required")
	}
	if c.MagicSpore.ConsumerSecret == "" {
		return NewValidationError("MAGIC_CONSUMER_SECRET is required")
	}
	if c.OITAM.ConsumerKey == "" {
		return NewValidationError("OITAM_CONSUMER_KEY is required")
	}
	if c.OITAM.ConsumerSecret == "" {
		return NewValidationError("OITAM_CONSUMER_SECRET is required")
	}
	return nil
}

type ValidationError struct {
	Message string
}

func (e *ValidationError) Error() string {
	return e.Message
}

func NewValidationError(message string) *ValidationError {
	return &ValidationError{Message: message}
}