package main

import (
	"log"
	"os"
	"paypal-proxy/internal/config"
	"paypal-proxy/internal/handlers"
	"paypal-proxy/internal/services"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
	"github.com/sirupsen/logrus"
)

func main() {
	// Load environment variables
	if err := godotenv.Load(); err != nil {
		logrus.Warn("No .env file found, using environment variables")
	}

	// Initialize configuration
	cfg := config.New()

	// Set up logging
	setupLogging(cfg.LogLevel)

	// Initialize services
	wooService := services.NewWooCommerceService(cfg)
	paypalService := services.NewPayPalProxyService(cfg, wooService)

	// Set Gin mode
	if cfg.Environment == "production" {
		gin.SetMode(gin.ReleaseMode)
	}

	// Initialize router
	router := gin.New()
	
	// Middleware
	router.Use(gin.Logger())
	router.Use(gin.Recovery())
	router.Use(handlers.CORSMiddleware())
	router.Use(handlers.SecurityHeaders())

	// Initialize handlers
	h := handlers.New(paypalService, wooService)

	// Routes
	setupRoutes(router, h)

	// Start server
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	logrus.Infof("🚀 PayPal Proxy Server starting on port %s", port)
	logrus.Infof("🔗 Environment: %s", cfg.Environment)
	
	if err := router.Run(":" + port); err != nil {
		log.Fatal("Failed to start server:", err)
	}
}

func setupLogging(level string) {
	logrus.SetFormatter(&logrus.JSONFormatter{})
	
	switch level {
	case "debug":
		logrus.SetLevel(logrus.DebugLevel)
	case "info":
		logrus.SetLevel(logrus.InfoLevel)
	case "warn":
		logrus.SetLevel(logrus.WarnLevel)
	case "error":
		logrus.SetLevel(logrus.ErrorLevel)
	default:
		logrus.SetLevel(logrus.InfoLevel)
	}
}

func setupRoutes(router *gin.Engine, h *handlers.Handler) {
	// Health check
	router.GET("/health", h.HealthCheck)
	
	// Main endpoints
	router.GET("/redirect", h.PaymentRedirect)
	router.GET("/paypal-return", h.PayPalReturn)
	router.GET("/paypal-cancel", h.PayPalCancel)
	router.POST("/webhook", h.WebhookHandler)
	
	// API routes
	api := router.Group("/api/v1")
	{
		api.GET("/order/:id", h.GetOrder)
		api.POST("/order", h.CreateOrder)
		api.PUT("/order/:id", h.UpdateOrder)
		api.GET("/status/:id", h.GetOrderStatus)
	}
}