#!/bin/bash

echo "🔧 Server Setup and Configuration Helper"
echo "======================================="

SERVER_USER="mycoadmin"
SERVER_HOST="91.99.141.217"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

show_help() {
    echo -e "${BLUE}Available commands:${NC}"
    echo "  ./server-setup.sh deploy    - Full deployment"
    echo "  ./server-setup.sh status    - Check service status"
    echo "  ./server-setup.sh logs      - View service logs"
    echo "  ./server-setup.sh restart   - Restart service"
    echo "  ./server-setup.sh config    - Edit configuration"
    echo "  ./server-setup.sh test      - Test the service"
    echo "  ./server-setup.sh ssl       - Setup SSL certificate"
    echo "  ./server-setup.sh help      - Show this help"
}

deploy() {
    echo -e "${BLUE}🚀 Starting full deployment...${NC}"
    ./deploy-server.sh
}

status() {
    echo -e "${BLUE}📊 Checking service status...${NC}"
    ssh $SERVER_USER@$SERVER_HOST "sudo systemctl status paypal-proxy --no-pager"
}

logs() {
    echo -e "${BLUE}📄 Viewing service logs (Press Ctrl+C to exit)...${NC}"
    ssh $SERVER_USER@$SERVER_HOST "sudo journalctl -u paypal-proxy -f"
}

restart() {
    echo -e "${BLUE}🔄 Restarting service...${NC}"
    ssh $SERVER_USER@$SERVER_HOST "sudo systemctl restart paypal-proxy && sudo systemctl status paypal-proxy --no-pager"
}

config() {
    echo -e "${BLUE}⚙️  Opening configuration editor...${NC}"
    ssh $SERVER_USER@$SERVER_HOST "sudo nano /opt/paypal-proxy/.env"
    echo -e "${YELLOW}Configuration updated. Restarting service...${NC}"
    restart
}

test() {
    echo -e "${BLUE}🧪 Testing service...${NC}"
    echo ""
    echo "Health Check:"
    curl -s http://$SERVER_HOST/health | jq . 2>/dev/null || curl -s http://$SERVER_HOST/health
    echo ""
    echo ""
    echo "Service Status:"
    status
}

setup_ssl() {
    echo -e "${BLUE}🔒 Setting up SSL certificate...${NC}"
    ssh $SERVER_USER@$SERVER_HOST << 'ENDSSH'
# Install certbot if not present
if ! command -v certbot &> /dev/null; then
    sudo apt update
    sudo apt install -y certbot python3-certbot-nginx
fi

# Get SSL certificate
echo "Setting up SSL for pay.magicspore.com..."
sudo certbot --nginx -d pay.magicspore.com --non-interactive --agree-tos --email admin@magicspore.com --redirect

# Test renewal
sudo certbot renew --dry-run

echo "✅ SSL certificate setup complete!"
echo "🔗 HTTPS URL: https://pay.magicspore.com/health"
ENDSSH
}

case "$1" in
    deploy)
        deploy
        ;;
    status)
        status
        ;;
    logs)
        logs
        ;;
    restart)
        restart
        ;;
    config)
        config
        ;;
    test)
        test
        ;;
    ssl)
        setup_ssl
        ;;
    help|*)
        show_help
        ;;
esac