#!/bin/bash

echo "🚀 PayPal Proxy Go - Server Deployment"
echo "======================================"

# Server configuration
SERVER_USER="mycoadmin"
SERVER_HOST="91.99.141.217"
SERVER_PATH="/opt/paypal-proxy"
SERVICE_NAME="paypal-proxy"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}🔧 Server Details:${NC}"
echo "User: $SERVER_USER"
echo "Host: $SERVER_HOST"
echo "Path: $SERVER_PATH"
echo ""

# Check if we can connect to the server
echo -e "${BLUE}🔌 Testing SSH connection...${NC}"
ssh -o ConnectTimeout=10 -o BatchMode=yes $SERVER_USER@$SERVER_HOST exit
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Cannot connect to server. Please check:${NC}"
    echo "1. SSH key is added: ssh-copy-id $SERVER_USER@$SERVER_HOST"
    echo "2. Server is accessible"
    echo "3. Username and IP are correct"
    exit 1
fi
echo -e "${GREEN}✅ SSH connection successful${NC}"

# Create deployment archive
echo -e "${BLUE}📦 Creating deployment archive...${NC}"
tar -czf paypal-proxy-deploy.tar.gz \
    --exclude='bin' \
    --exclude='.git' \
    --exclude='*.log' \
    --exclude='paypal-proxy-deploy.tar.gz' \
    .

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Failed to create deployment archive${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Deployment archive created${NC}"

# Transfer files to server
echo -e "${BLUE}📤 Transferring files to server...${NC}"
scp paypal-proxy-deploy.tar.gz $SERVER_USER@$SERVER_HOST:/tmp/

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Failed to transfer files${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Files transferred successfully${NC}"

# Deploy on server
echo -e "${BLUE}🚀 Deploying on server...${NC}"
ssh $SERVER_USER@$SERVER_HOST << 'ENDSSH'
#!/bin/bash

# Colors for remote execution
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

SERVER_PATH="/opt/paypal-proxy"
SERVICE_NAME="paypal-proxy"

echo -e "${BLUE}🔧 Setting up deployment directory...${NC}"

# Create directory and extract
sudo mkdir -p $SERVER_PATH
cd $SERVER_PATH
sudo tar -xzf /tmp/paypal-proxy-deploy.tar.gz
sudo chown -R $USER:$USER .

echo -e "${GREEN}✅ Files extracted to $SERVER_PATH${NC}"

# Install Go if not present
if ! command -v go &> /dev/null; then
    echo -e "${BLUE}📦 Installing Go...${NC}"
    wget https://golang.org/dl/go1.21.5.linux-amd64.tar.gz
    sudo rm -rf /usr/local/go
    sudo tar -C /usr/local -xzf go1.21.5.linux-amd64.tar.gz
    echo 'export PATH=$PATH:/usr/local/go/bin' | sudo tee -a /etc/profile
    export PATH=$PATH:/usr/local/go/bin
    echo -e "${GREEN}✅ Go installed${NC}"
else
    echo -e "${GREEN}✅ Go already installed${NC}"
fi

# Install Docker if not present
if ! command -v docker &> /dev/null; then
    echo -e "${BLUE}🐳 Installing Docker...${NC}"
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    sudo usermod -aG docker $USER
    echo -e "${GREEN}✅ Docker installed${NC}"
fi

# Install Docker Compose if not present
if ! command -v docker-compose &> /dev/null; then
    echo -e "${BLUE}🐳 Installing Docker Compose...${NC}"
    sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
    echo -e "${GREEN}✅ Docker Compose installed${NC}"
fi

# Setup environment
echo -e "${BLUE}⚙️  Setting up environment...${NC}"
if [ ! -f .env ]; then
    cp .env.example .env
    echo -e "${YELLOW}⚠️  Please edit .env file with your API keys${NC}"
fi

# Build and start
echo -e "${BLUE}🔨 Building application...${NC}"
export PATH=$PATH:/usr/local/go/bin
go mod tidy
go build -o bin/paypal-proxy .

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Build successful${NC}"
else
    echo -e "${RED}❌ Build failed${NC}"
    exit 1
fi

# Create systemd service
echo -e "${BLUE}🔧 Creating systemd service...${NC}"
sudo tee /etc/systemd/system/$SERVICE_NAME.service > /dev/null <<EOF
[Unit]
Description=PayPal Proxy Go Service
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$SERVER_PATH
ExecStart=$SERVER_PATH/bin/paypal-proxy
Restart=always
RestartSec=5
Environment=PATH=/usr/local/go/bin:/usr/bin:/bin
EnvironmentFile=$SERVER_PATH/.env

[Install]
WantedBy=multi-user.target
EOF

# Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable $SERVICE_NAME
sudo systemctl stop $SERVICE_NAME 2>/dev/null || true
sudo systemctl start $SERVICE_NAME

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Service started successfully${NC}"
else
    echo -e "${RED}❌ Failed to start service${NC}"
    sudo systemctl status $SERVICE_NAME
    exit 1
fi

# Setup nginx reverse proxy
echo -e "${BLUE}🌐 Setting up Nginx reverse proxy...${NC}"
if ! command -v nginx &> /dev/null; then
    sudo apt update
    sudo apt install -y nginx
fi

# Create nginx configuration
sudo tee /etc/nginx/sites-available/paypal-proxy > /dev/null <<EOF
server {
    listen 80;
    server_name pay.magicspore.com 91.99.141.217;

    location / {
        proxy_pass http://localhost:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

# Enable nginx site
sudo ln -sf /etc/nginx/sites-available/paypal-proxy /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

echo -e "${GREEN}✅ Nginx configured${NC}"

# Install UFW firewall rules
echo -e "${BLUE}🔒 Configuring firewall...${NC}"
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw --force enable

echo -e "${GREEN}✅ Firewall configured${NC}"

# Show status
echo -e "${BLUE}📊 Deployment Status:${NC}"
sudo systemctl status $SERVICE_NAME --no-pager
echo ""
echo -e "${BLUE}🔗 Service URLs:${NC}"
echo "Health Check: http://91.99.141.217/health"
echo "Payment URL: http://91.99.141.217/redirect?orderId=123"
echo "Domain: http://pay.magicspore.com/health (if DNS configured)"
echo ""
echo -e "${BLUE}📋 Management Commands:${NC}"
echo "Status: sudo systemctl status $SERVICE_NAME"
echo "Logs: sudo journalctl -u $SERVICE_NAME -f"
echo "Restart: sudo systemctl restart $SERVICE_NAME"
echo "Stop: sudo systemctl stop $SERVICE_NAME"
echo ""
echo -e "${YELLOW}⚠️  Next Steps:${NC}"
echo "1. Edit /opt/paypal-proxy/.env with your API keys"
echo "2. Restart service: sudo systemctl restart $SERVICE_NAME"
echo "3. Configure DNS: pay.magicspore.com -> 91.99.141.217"
echo "4. Set up SSL certificate (Let's Encrypt recommended)"

ENDSSH

# Clean up local files
rm -f paypal-proxy-deploy.tar.gz

echo ""
echo -e "${GREEN}🎉 Deployment completed successfully!${NC}"
echo ""
echo -e "${BLUE}📋 Next Steps:${NC}"
echo "1. Configure API keys on server:"
echo "   ssh $SERVER_USER@$SERVER_HOST"
echo "   sudo nano $SERVER_PATH/.env"
echo "   sudo systemctl restart $SERVICE_NAME"
echo ""
echo "2. Test the deployment:"
echo "   curl http://91.99.141.217/health"
echo ""
echo "3. Configure DNS (optional):"
echo "   Point pay.magicspore.com to 91.99.141.217"
echo ""
echo "4. Set up SSL certificate:"
echo "   sudo certbot --nginx -d pay.magicspore.com"
echo ""
echo -e "${GREEN}✅ Your PayPal Proxy is now running on the server!${NC}"